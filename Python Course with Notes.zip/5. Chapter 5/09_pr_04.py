s = {20, 20.0, "20"}
print(s)
print(len(s)) 