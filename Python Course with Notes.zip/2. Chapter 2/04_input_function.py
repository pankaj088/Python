a = input("Enter a number: ")
a = int(a) # Convert a to an Integer(if possible)
print(type(a))