# n! = (n-1)! * n 
# sum(n) = sum(n-1) + n